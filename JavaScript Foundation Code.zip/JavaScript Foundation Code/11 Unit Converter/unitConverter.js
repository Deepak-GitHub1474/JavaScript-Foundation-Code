
// Formula: Fahrenheit = (Celsius * 1.8) + 32

function convertTemperature(celsius){
    let fahrenheit = (celsius * 1.8) + 32;
    return fahrenheit;
}

let fahrenheit = convertTemperature(20);
console.log(fahrenheit);

// Output : 68