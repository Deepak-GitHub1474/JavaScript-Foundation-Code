
let paragraph = document.querySelector("p");
let words = paragraph.innerText.split(" ");

words.forEach(word => {
  if (word.length > 8) {
    paragraph.innerHTML = paragraph.innerHTML.replace(word, `<span style="background-color: yellow;">${word}</span>`);
  }
});