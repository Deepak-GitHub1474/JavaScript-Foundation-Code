let account = {
    name: "Deepak Chaudhary",
    balance: 10000,
    deposit: function(amount) {
      this.balance += amount;
      console.log(`Name: ${account.name}`);
      console.log(`Deposited ₹${amount}, Current Balance: ${account.balance}`);
    },
    withdraw: function(amount) {
      this.balance -= amount;
      console.log(`Withdrew ₹${amount}, Current Balance: ${account.balance}`);
    },
  };
  
  // Update the account
  account.deposit(100);
  account.withdraw(50);
  account.withdraw(500);
  
  /*
  Output:
  
  Name: Deepak Chaudhary
  Deposited ₹100, Current Balance: 10100
  Withdrew ₹50, Current Balance: 10050
  Withdrew ₹500, Current Balance: 9550
  
  */
