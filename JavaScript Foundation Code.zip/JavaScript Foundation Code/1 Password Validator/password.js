// using ternary operator:

let password1 = true;

password1? console.log("password matched. password validation successful."):console.log("password didn't match. password validation unsuccessful.");