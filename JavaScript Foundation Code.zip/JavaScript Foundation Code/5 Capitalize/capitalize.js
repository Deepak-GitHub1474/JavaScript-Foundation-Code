let userName = "Deepak";
let upperCaseName = userName[0] === userName[0].toLowerCase() ? userName[0].toUpperCase() + userName.slice(1) : userName;
console.log(upperCaseName)