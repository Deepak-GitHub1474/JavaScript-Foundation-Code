
function doubleCartItems(cartItems){
    for(let i =0; i < cartItems.length; i++){
        cartItems[i] *= 2;
    }
    return cartItems;
}

let updatedCartItem = doubleCartItems([1,3,2]);
console.log(updatedCartItem);

// Output : [ 2, 6, 4 ]