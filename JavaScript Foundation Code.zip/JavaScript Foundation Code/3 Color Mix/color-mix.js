let mixcolor = "yellow and blue";

switch(mixcolor){

    case "red and blue" :
    case "blue and red" :
        console.log("purple");
        break;

    case "red and yellow" :
    case "yellow and red" :
        console.log("orange");
        break;

    case "blue and yellow" :
    case "yellow and blue" :
        console.log("green");
        break;
    
    default: 
        console.log("invalid color combination.")
    break;
}

// Output : green
