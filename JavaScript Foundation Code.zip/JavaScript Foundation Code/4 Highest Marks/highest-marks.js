let marks = [50, 80, 65, 45, 90]
let biggestNumber = marks[0] > marks[1] ? marks[0] : marks[1]
for (let i = 2; i < marks.length; i++){
    biggestNumber = biggestNumber > marks[i] ? biggestNumber : marks[i]
}
console.log(biggestNumber);

// Output : 90
