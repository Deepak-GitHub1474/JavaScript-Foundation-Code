const image = document.getElementById("image");

window.addEventListener("load", () =>{
    image.style.position = "absolute"; 
})

document.onkeydown = function (e) {
    switch (e.keyCode) {
        case 37:
            image.style.left = (image.offsetLeft - 10) + 'px';
            break;
        case 38:
            image.style.top = (image.offsetTop - 10) + 'px';
            break;
        case 39:
            image.style.left = (image.offsetLeft + 10) + 'px';
            break;
        case 40:
            image.style.top = (image.offsetTop + 10) + 'px';
            break;
    }
};