let input_name = "deepak Chaudhary";
let vowel_count = input_name.match(/[aeiouAEIOU]/gi).length;
console.log(vowel_count);

// Outputs : 6