function addTodo(){
   let input = document.getElementById("input").value;
   let li = document.createElement("li");
   li.innerText = input;
   document.getElementById("list").appendChild(li);
   document.getElementById("input").value = "";

   let btnRemove = document.createElement("button");
   btnRemove.className = "btn-remove";
   btnRemove.innerText = "X";
   li.appendChild(btnRemove);

   btnRemove.addEventListener("click", function() {
    document.getElementById("list").removeChild(li);
   })
}

let btnAdd = document.getElementById("btn-add");

btnAdd.onclick = ()=>{
    addTodo();
}