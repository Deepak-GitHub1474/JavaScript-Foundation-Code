function splitBill(costOfEachDish, numberOfPeople){
    let totalBill = costOfEachDish;
    let billPerPerson =  costOfEachDish/numberOfPeople;
    return {
        total_bill: totalBill,
        bill_per_person: billPerPerson
    }
}

let bill = splitBill(500, 5)
console.log(bill)

// Output : { total_bill: 500, bill_per_person: 100 }
