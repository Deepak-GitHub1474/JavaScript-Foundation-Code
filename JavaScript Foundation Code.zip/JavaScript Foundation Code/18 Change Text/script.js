let heading = document.getElementById("heading")
let btn = document.getElementById("btn");

btn.onclick = () =>{
    if(heading.textContent === "The most affordable learning platform"){
        heading.textContent = "PW Skils"
    }
    else{
        heading.textContent = "The most affordable learning platform"
    }
}