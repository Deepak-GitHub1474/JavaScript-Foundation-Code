let customerCart = [
    {unitPrice: 50, quantity: 3},
    {unitPrice: 100, quantity: 2},
    {unitPrice: 400, quantity: 1}
];

const calculateTotalCost = (cart) => {
    let totalCost = 0;
    cart.forEach(item => {
        totalCost += item.unitPrice * item.quantity;
    });
    return totalCost;
};

console.log(calculateTotalCost(customerCart));
