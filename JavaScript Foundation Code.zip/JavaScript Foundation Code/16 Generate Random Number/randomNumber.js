(() => {
    let randomNumber = Math.floor(Math.random()*101);
    console.log(randomNumber);
})();



(() => {
  let randomNumber = Math.floor(Math.random() * 100) + 1;
  console.log(randomNumber);
})();