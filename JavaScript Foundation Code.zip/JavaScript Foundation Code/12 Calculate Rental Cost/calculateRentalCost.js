function calculateRentalCost(daysRented, carType) {
  let cost;

  switch (carType) {
    case "economy":
      cost = daysRented * 4000;
      break;
    case "midsize":
      cost = daysRented * 10000;
      break;
    case "luxury":
      cost = daysRented * 20000;
      break;
    default:
      cost = 0;
  }

  console.log(`Total cost for renting a ${carType} car for ${daysRented} days is $${cost}.`);
}

calculateRentalCost(5, "economy");
calculateRentalCost(5, "midsize");
calculateRentalCost(5, "luxury");

/*

Output:

Total cost for renting a economy car for 5 days is $20000.
Total cost for renting a midsize car for 5 days is $50000.
Total cost for renting a luxury car for 5 days is $100000.

                                                            */
