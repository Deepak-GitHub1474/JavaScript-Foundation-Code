const array = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30];

for(let i = 0; i < array.length; i++) {
  if(array[i] % 3 === 0 && array[i] % 2 !== 0) {
    console.log(array[i]);
  } else {
    continue;
  }
}

/* Output : 

        3
        9
        15
        21
        27
             */