const customerCart = ["white t-shirt", "black t-shirt", "iphone-13", "laptop", "iphone-13", "black t-shirt",]
const newCart = customerCart.filter((element, index, customerCart) =>{
    return index === customerCart.indexOf(element);
});
console.log(newCart);

// Output : [ 'white t-shirt', 'black t-shirt', 'iphone-13', 'laptop' ]