function changeColor(){
    let hexValues = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'];
    let hexColor = "#";
    for(let i =0; i<6; i++){
        let randomIndex = Math.floor(Math.random() * hexValues.length);
        hexColor += hexValues[randomIndex]; 
    }
    return hexColor; 
}

const btn = document.getElementById("btn");
btn.onclick = ()=>{
    let randomColor = changeColor();
    document.body.style.backgroundColor = randomColor; 
}
