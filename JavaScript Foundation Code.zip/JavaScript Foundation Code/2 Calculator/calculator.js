let num1 = 20;
let num2 = 10;
let operator = "/";

switch(operator){
    case "+":
        var result = num1 + num2;
        console.log (`Addition of num1 and num2 = ${result}`)
    break;

    case "-":
        var result = num1 - num2;
        console.log (`Subtraction of num1 and num2 = ${result}`)
    break;

    case "*":
        var result = num1 * num2;
        console.log (`Multiplication of num1 and num2 = ${result}`)
    break;

    case "/":
        var result = num1 / num2;
        console.log (`Division of num1 and num2 = ${result}`)
    break;
}

// Output : Division of num1 and num2 = 2