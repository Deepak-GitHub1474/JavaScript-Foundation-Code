let btn = document.getElementById("btn");

function validateForm(){
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let paragraph = document.getElementById("paragraph");
    if(email.includes("@") && password.length >= 8){
        paragraph.textContent = "valid email and password!"
        paragraph.style.color = "green";
    }
    else{
        paragraph.textContent = "invalid email or password!"
        paragraph.style.color = "red";
    }
};

btn.onclick = (event) =>{
    validateForm();
    event.preventDefault();
}
