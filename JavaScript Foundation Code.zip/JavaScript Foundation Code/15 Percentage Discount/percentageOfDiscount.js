let originPrice = 1000;
let discountedPrice = 500;

let percentageDiscount = (originPrice, discountedPrice) =>{
    return ((originPrice - discountedPrice)/originPrice * 100)
}

console.log(`Total ${percentageDiscount(originPrice, discountedPrice)}% discount`);

// Output: Total 50% discount