let arrayList = ["HTML", "CSS", "JavaScript", "React", "MongoDB", "SQL", "NoSQL"]
let index = 0;

function addItem(){
    let list = document.getElementById("list");

    if(index < arrayList.length){
        list.innerHTML += "<li>" + arrayList[index] + "</li>"
        index++;
    }
    else{
        alert("All items have been added")
    }
}

let btn = document.getElementById("btn");

btn.onclick = ()=>{
    addItem();
}